import React, { createContext, useContext, useRef, useState } from 'react';
import { Audio } from 'expo-av';

const AudioContext = createContext(null);

export function AudioProvider({ children }) {
  const soundRef = useRef(null);
  const queueRef = useRef([]);

  const [currentSong, setCurrentSong] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);

  const playSong = async (song, queue) => {
    console.log('playSong wywołane:', song.title, song.url);

    if (!song.url || song.url.trim() === '') {
      console.log('Brak URL - pomijam');
      return;
    }

    if (queue) queueRef.current = queue;

    try {
      if (soundRef.current) {
        await soundRef.current.stopAsync();
        await soundRef.current.unloadAsync();
        soundRef.current = null;
      }

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: true,
        staysActiveInBackground: true,
      });

      console.log('Ładuję audio z:', song.url);

      const { sound } = await Audio.Sound.createAsync(
        { uri: song.url.trim() },
        { shouldPlay: true, progressUpdateIntervalMillis: 500 },
        (status) => {
          if (status.isLoaded) {
            setPosition(status.positionMillis ?? 0);
            setDuration(status.durationMillis ?? 0);
            setIsPlaying(status.isPlaying);
            if (status.didJustFinish) {
              playNextInternal(song);
            }
          } else if (status.error) {
            console.log('Błąd statusu audio:', status.error);
          }
        }
      );

      soundRef.current = sound;
      setCurrentSong(song);
      setIsPlaying(true);
      console.log('Gra!');
    } catch (e) {
      console.log('Błąd playSong:', e.message);
    }
  };

  const playNextInternal = async (song) => {
    const q = queueRef.current;
    if (!q.length) return;
    const idx = q.findIndex(s => s.id === song.id);
    const next = q[(idx + 1) % q.length];
    if (next) await playSong(next);
  };

  const togglePlayPause = async () => {
    if (!soundRef.current) return;
    try {
      if (isPlaying) {
        await soundRef.current.pauseAsync();
      } else {
        await soundRef.current.playAsync();
      }
    } catch (e) {
      console.log('Błąd toggle:', e.message);
    }
  };

  const playNext = async () => {
    if (!currentSong) return;
    await playNextInternal(currentSong);
  };

  const playPrev = async () => {
    const q = queueRef.current;
    if (!q.length || !currentSong) return;
    const idx = q.findIndex(s => s.id === currentSong.id);
    const prev = q[(idx - 1 + q.length) % q.length];
    if (prev) await playSong(prev);
  };

  return (
    <AudioContext.Provider value={{
      currentSong, isPlaying, position, duration,
      playSong, togglePlayPause, playNext, playPrev,
    }}>
      {children}
    </AudioContext.Provider>
  );
}

export function useAudio() {
  return useContext(AudioContext);
}