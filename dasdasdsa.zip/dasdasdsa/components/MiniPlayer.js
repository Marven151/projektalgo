import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated } from 'react-native';

export default function MiniPlayer({ song, isPlaying, position, duration, onPlayPause, onNext, onPrev }) {
  const slideAnim = useRef(new Animated.Value(100)).current;
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (song) {
      setVisible(true);
      Animated.spring(slideAnim, { toValue: 0, useNativeDriver: true, tension: 80 }).start();
    } else {
      Animated.timing(slideAnim, { toValue: 100, duration: 200, useNativeDriver: true }).start(() => setVisible(false));
    }
  }, [song]);

  if (!visible) return null;

  const progress = duration > 0 ? position / duration : 0;
  const formatTime = (ms) => {
    const s = Math.floor(ms / 1000);
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  };

  return (
    <Animated.View style={[styles.container, { transform: [{ translateY: slideAnim }] }]}>
    
      <View style={styles.progressBg}>
        <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
      </View>

      <View style={styles.content}>
        
        <View style={styles.info}>
          <View style={styles.albumThumb}>
            <Text style={styles.albumEmoji}>🎵</Text>
          </View>
          <View style={styles.textBlock}>
            <Text style={styles.title} numberOfLines={1}>{song?.title}</Text>
            <Text style={styles.artist} numberOfLines={1}>{song?.artist}</Text>
          </View>
        </View>

      
        <Text style={styles.time}>{formatTime(position)}</Text>

       
        <View style={styles.controls}>
          <TouchableOpacity onPress={onPrev} style={styles.controlBtn}>
            <Text style={styles.controlIcon}>⏮</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onPlayPause} style={styles.playBtn}>
            <Text style={styles.playIcon}>{isPlaying ? '⏸' : '▶'}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onNext} style={styles.controlBtn}>
            <Text style={styles.controlIcon}>⏭</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute', bottom: 60, left: 0, right: 0,
    backgroundColor: '#282828',
    borderTopWidth: 1, borderTopColor: '#333',
    shadowColor: '#000', shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.4, shadowRadius: 8, elevation: 20,
  },
  progressBg: { height: 3, backgroundColor: '#404040' },
  progressFill: { height: 3, backgroundColor: '#1db954' },
  content: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 10, gap: 8,
  },
  info: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  albumThumb: {
    width: 44, height: 44, borderRadius: 6,
    backgroundColor: '#333', alignItems: 'center', justifyContent: 'center',
  },
  albumEmoji: { fontSize: 22 },
  textBlock: { flex: 1 },
  title: { color: '#fff', fontSize: 14, fontWeight: '600' },
  artist: { color: '#b3b3b3', fontSize: 12 },
  time: { color: '#888', fontSize: 11, minWidth: 32, textAlign: 'center' },
  controls: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  controlBtn: { padding: 8 },
  controlIcon: { fontSize: 18, color: '#fff' },
  playBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: '#1db954', alignItems: 'center', justifyContent: 'center',
  },
  playIcon: { fontSize: 16, color: '#000' },
});