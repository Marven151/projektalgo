import React, { useState, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet, Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { useAudio } from '../context/AudioContext';

const STORAGE_KEY = '@music_songs';

export default function SongListScreen() {
  const [songs, setSongs] = useState([]);
  const [filter, setFilter] = useState('');
  const { playSong, currentSong } = useAudio();

  useFocusEffect(
    useCallback(() => { loadSongs(); }, [])
  );

  const loadSongs = async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      setSongs(stored ? JSON.parse(stored) : []);
    } catch (e) {
      console.log('Load error:', e);
    }
  };

  const deleteSong = (id, title) => {
    Alert.alert('Usuń utwór', `Usunąć "${title}"?`, [
      { text: 'Anuluj', style: 'cancel' },
      {
        text: 'Usuń', style: 'destructive',
        onPress: async () => {
          const updated = songs.filter(s => s.id !== id);
          await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
          setSongs(updated);
        },
      },
    ]);
  };

  const filters = [
    { id: 0, label: 'Wszystkie', value: '' },
    { id: 1, label: 'Gry ', value: 'gry' },
    { id: 2, label: 'Kod ', value: 'coding' },
    { id: 3, label: 'Trening ', value: 'trening' },
    { id: 4, label: 'Film ', value: 'film' },
  ];

  const filteredSongs = filter ? songs.filter(s => s.tag === filter) : songs;

  const handlePress = (song) => {
    console.log('Kliknięto:', song.title);
    playSong(song, filteredSongs);
  };

  const renderSong = ({ item, index }) => {
    const isActive = currentSong?.id === item.id;
    return (
      <TouchableOpacity
        style={[styles.songRow, isActive && styles.songRowActive]}
        onPress={() => handlePress(item)}
        onLongPress={() => deleteSong(item.id, item.title)}
        activeOpacity={0.7}
      >
        <View style={styles.indexContainer}>
          <Text style={isActive ? styles.playingIcon : styles.index}>
            {isActive ? '▶' : index + 1}
          </Text>
        </View>
        <View style={styles.songInfo}>
          <Text style={[styles.songTitle, isActive && styles.songTitleActive]} numberOfLines={1}>
            {item.title}
          </Text>
          <Text style={styles.songArtist} numberOfLines={1}>{item.artist}</Text>
        </View>
        <View style={styles.right}>
          <View style={styles.tagBadge}>
            <Text style={styles.tagBadgeText}>{item.tag}</Text>
          </View>
          {!item.url && (
            <Text style={styles.noUrl}>bez audio</Text>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Moja Playlista</Text>

      <View style={styles.filterRow}>
        {filters.map(f => (
          <TouchableOpacity
            key={f.id}
            style={[styles.filterBtn, filter === f.value && styles.filterActive]}
            onPress={() => setFilter(f.value)}
          >
            <Text style={[styles.filterText, filter === f.value && styles.filterTextActive]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {filteredSongs.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyIcon}>🎵</Text>
          <Text style={styles.emptyText}>
            {songs.length === 0 ? 'Brak piosenek. Dodaj pierwszą!' : 'Brak w tej kategorii.'}
          </Text>
        </View>
      ) : (
        <FlatList
          data={filteredSongs}
          renderItem={renderSong}
          keyExtractor={item => item.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContent}
        />
      )}

      <View style={styles.hint}>
        <Text style={styles.hintText}>Przytrzymaj utwór, aby usunąć</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#121212' },
  header: {
    fontSize: 28, fontWeight: 'bold', color: '#fff',
    textAlign: 'center', paddingTop: 50, paddingBottom: 20, backgroundColor: '#000',
  },
  filterRow: {
    flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 15,
    backgroundColor: '#000', flexWrap: 'wrap', gap: 8,
  },
  filterBtn: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.1)' },
  filterActive: { backgroundColor: '#1db954' },
  filterText: { color: '#b3b3b3', fontSize: 13, fontWeight: '500' },
  filterTextActive: { color: '#000' },
  listContent: { padding: 20, paddingBottom: 140 },
  songRow: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#181818',
    marginBottom: 11, padding: 17, borderRadius: 8,
  },
  songRowActive: { backgroundColor: '#1a2e1a', borderWidth: 1, borderColor: '#1db954' },
  indexContainer: { width: 30, alignItems: 'center' },
  index: { color: '#b3b3b3', fontSize: 16, fontWeight: '600' },
  playingIcon: { color: '#1db954', fontSize: 16 },
  songInfo: { flex: 1, marginLeft: 16 },
  songTitle: { color: '#fff', fontSize: 17, fontWeight: '600', marginBottom: 2 },
  songTitleActive: { color: '#1db954' },
  songArtist: { color: '#b3b3b3', fontSize: 15 },
  right: { alignItems: 'flex-end', gap: 4 },
  tagBadge: { backgroundColor: 'rgba(29,185,84,0.15)', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  tagBadgeText: { color: '#1db954', fontSize: 12, fontWeight: '600' },
  noUrl: { color: '#555', fontSize: 10 },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyIcon: { fontSize: 56, marginBottom: 16 },
  emptyText: { color: '#b3b3b3', fontSize: 16, textAlign: 'center' },
  hint: { alignItems: 'center', paddingBottom: 12 },
  hintText: { color: '#444', fontSize: 12 },
});