import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ScrollView, Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = '@music_songs';

export default function AddSongScreen() {
  const [form, setForm] = useState({
    title: '',
    artist: '',
    tag: 'gry',
    url: '',
  });

  const saveSong = async () => {
    if (!form.title.trim() || !form.artist.trim()) {
      Alert.alert('Błąd', 'Podaj tytuł i artystę');
      return;
    }

    try {
      const songs = await AsyncStorage.getItem(STORAGE_KEY);
      const songList = songs ? JSON.parse(songs) : [];
      const newSong = { id: Date.now().toString(), ...form };
      songList.push(newSong);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(songList));
      Alert.alert('Dodano!', 'Utwór zapisany w playliście');
      setForm({ title: '', artist: '', tag: 'gry', url: '' });
    } catch (e) {
      Alert.alert('Błąd', 'Nie udało się zapisać');
    }
  };

  const tags = [
    { value: 'gry', label: ' Gry' },
    { value: 'coding', label: ' Programowanie' },
    { value: 'trening', label: ' Trening' },
    { value: 'film', label: ' Film' },
  ];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Dodaj do playlisty</Text>

      <View style={styles.form}>
        <Text style={styles.label}>Tytuł utworu</Text>
        <TextInput
          style={styles.input}
          placeholder="np. Bohemian Rhapsody"
          placeholderTextColor="#555"
          value={form.title}
          onChangeText={text => setForm({ ...form, title: text })}
        />

        <Text style={styles.label}>Artysta</Text>
        <TextInput
          style={styles.input}
          placeholder="np. Queen"
          placeholderTextColor="#555"
          value={form.artist}
          onChangeText={text => setForm({ ...form, artist: text })}
        />

        <Text style={styles.label}>Link do MP3 </Text>
        <TextInput
          style={styles.input}
          placeholder="https://... .mp3"
          placeholderTextColor="#555"
          value={form.url}
          onChangeText={text => setForm({ ...form, url: text })}
          autoCapitalize="none"
          keyboardType="url"
        />
        <Text style={styles.hint}>
         
        </Text>

        <Text style={styles.label}>Playlista</Text>
        <View style={styles.tagGrid}>
          {tags.map(t => (
            <TouchableOpacity
              key={t.value}
              style={[styles.tagBtn, form.tag === t.value && styles.tagActive]}
              onPress={() => setForm({ ...form, tag: t.value })}
            >
              <Text style={[styles.tagText, form.tag === t.value && styles.tagTextActive]}>
                {t.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity style={styles.saveBtn} onPress={saveSong}>
          <Text style={styles.saveBtnText}>Zapisz do playlisty</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#121212' },
  title: {
    fontSize: 26, fontWeight: 'bold', color: '#fff',
    textAlign: 'center', paddingTop: 50, paddingBottom: 30,
  },
  form: { backgroundColor: '#181818', margin: 20, padding: 24, borderRadius: 16 },
  label: { color: '#b3b3b3', fontSize: 13, fontWeight: '600', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 },
  input: {
    backgroundColor: '#2a2a2a', color: '#fff', padding: 16,
    borderRadius: 10, fontSize: 16, marginBottom: 8,
    borderWidth: 1, borderColor: '#404040',
  },
  hint: { color: '#555', fontSize: 12, marginBottom: 24 },
  tagGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 28 },
  tagBtn: {
    flex: 1, minWidth: '44%', backgroundColor: 'rgba(255,255,255,0.08)',
    paddingVertical: 14, borderRadius: 10, alignItems: 'center',
  },
  tagActive: { backgroundColor: '#1db954' },
  tagText: { color: '#b3b3b3', fontSize: 15, fontWeight: '600' },
  tagTextActive: { color: '#000' },
  saveBtn: { backgroundColor: '#1db954', padding: 18, borderRadius: 12, alignItems: 'center' },
  saveBtnText: { color: '#000', fontSize: 17, fontWeight: '700' },
});