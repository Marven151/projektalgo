import React from 'react';
import { Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Provider as PaperProvider } from 'react-native-paper';
import { MD3LightTheme as DefaultTheme } from 'react-native-paper';

import { AudioProvider, useAudio } from './context/AudioContext';
import SongListScreen from './screens/SongListScreen';
import AddSongScreen from './screens/AddSongScreen';
import SearchScreen from './screens/searchScreen';
import MiniPlayer from './components/MiniPlayer';

const Tab = createBottomTabNavigator();

const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#1db954',
    background: '#121212',
    surface: '#181818',
    onSurface: '#fff',
    elevation: {
      level0: 'transparent',
      level1: '#1a1a1a',
      level2: '#1e1e1e',
    },
  },
};

// Osobny komponent żeby móc użyć useAudio() wewnątrz AudioProvider
function AppInner() {
  const { currentSong, isPlaying, position, duration, togglePlayPause, playNext, playPrev } = useAudio();

  return (
    <View style={{ flex: 1 }}>
      <Tab.Navigator
        screenOptions={{
          tabBarActiveTintColor: '#1db954',
          tabBarInactiveTintColor: '#b3b3b3',
          tabBarStyle: {
            backgroundColor: '#000',
            borderTopWidth: 0,
            height: 60,
            paddingBottom: 5,
          },
          headerStyle: { backgroundColor: '#000' },
          headerTintColor: '#fff',
        }}
      >
        <Tab.Screen
          name="Playlisty"
          component={SongListScreen}
          options={{
            tabBarLabel: 'Playlista',
            tabBarIcon: ({ color }) => <TabIcon label="🎵" color={color} />,
            headerTitleStyle: { fontWeight: 'bold' },
          }}
        />
        <Tab.Screen
          name="Dodaj"
          component={AddSongScreen}
          options={{
            tabBarLabel: 'Dodaj',
            tabBarIcon: ({ color }) => <TabIcon label="➕" color={color} />,
          }}
        />
        <Tab.Screen
          name="Szukaj"
          component={SearchScreen}
          options={{
            tabBarLabel: 'Szukaj',
            tabBarIcon: ({ color }) => <TabIcon label="🔍" color={color} />,
          }}
        />
      </Tab.Navigator>

      <MiniPlayer
        song={currentSong}
        isPlaying={isPlaying}
        position={position}
        duration={duration}
        onPlayPause={togglePlayPause}
        onNext={playNext}
        onPrev={playPrev}
      />
    </View>
  );
}

export default function App() {
  return (
    <PaperProvider theme={theme}>
      <AudioProvider>
        <NavigationContainer>
          <AppInner />
        </NavigationContainer>
      </AudioProvider>
    </PaperProvider>
  );
}

function TabIcon({ label, color }) {
  return <Text style={{ fontSize: 20, color }}>{label}</Text>;
}